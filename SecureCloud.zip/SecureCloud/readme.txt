Ako to rozchodit? 

1. Treba nainštalovať mongoDB.  -> https://www.mongodb.org/
2. Treba nainštalovať nodeJS(nejaku novsiu verziu). -> https://nodejs.org/

SPUSTENIE:

mongod —-dbpath <zdrojovy kod>/data
node <zdrojovy kod>/bin/www

a potom snad uz len browserom na localhost:9117

Popripade ze sa vam nechce nic rozbehavat mam k dispozicii raspberry pi server.
Na adrese pkovacs.sk:9117 bezi aplikacia(v pripade ze nevypnu prud a nespadne mi screen).
Este to nemam nastavene aby sa automaticky obnovilo.
